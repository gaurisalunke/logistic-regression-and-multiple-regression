#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import seaborn as sb
import matplotlib.pyplot as plt
from sklearn import linear_model
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
import warnings
from sklearn.linear_model import LinearRegression
warnings.filterwarnings("ignore")
data=pd.read_excel("commodity.xlsx")
data


# In[2]:


data.shape 


# In[3]:


data.duplicated().sum()


# In[4]:


data.isnull().sum()


# In[5]:


corr=sb.heatmap((data.corr()),annot=True)


# In[6]:


X=data[['High','Low','Volume','Open']]
Y=data['Close']


# In[7]:


Reg=linear_model.LinearRegression()
Reg.fit(X,Y)


# In[8]:


Reg.coef_                             ## for + ind increase dependent increase and for - independent incease deoendent decreases


# In[9]:


Reg.intercept_                    ## the mean for Y when all of the x takse value 0


# In[10]:


print("R square =",Reg.score(X,Y))     ## how well the regression model explains observed data


# In[11]:


X_train,X_test,Y_train,Y_test=train_test_split(X,Y,test_size=0.2,random_state=0)
print("X_train")


# In[12]:


#View shapes of splitted data
print("X_train:",X_train.shape)
print("X_test:",X_test.shape)
print("Y_train:",Y_train.shape)
print("Y_test:",Y_test.shape)


# In[13]:


Reg = LinearRegression()
Reg.fit(X_train,Y_train)


# In[14]:


Y_pred=Reg.predict(X_test)
Y_pred


# In[15]:


Accuracy=r2_score(Y_test,Y_pred)*100
print("Accuracy of the model is %.2f" %Accuracy)


# In[16]:


plt.scatter(Y_test,Y_pred)
plt.xlabel("Actual")
plt.ylabel("Predicted")


# In[17]:


sb.regplot(x=Y_test,y=Y_pred,ci=None,color='red')


# In[22]:


get_ipython().system('pip install statsmodel')
import scipy.signal.signaltools

def _centered(arr, newsize):
    # Return the center newsize portion of the array.
    newsize = np.asarray(newsize)
    currsize = np.array(arr.shape)
    startind = (currsize - newsize)  // 2
    endind = startind + newsize
    myslice = [slice(startind[k], endind[k]) for k in range(len(endind))]
    return arr[tuple(myslice)]

scipy.signal.signaltools._centered = _centered
import statsmodels.api as sm
import pandas as pd
x= sm.add_constant(X)
result = sm.OLS(Y,X).fit()
print(result.summary())


# In[ ]:




