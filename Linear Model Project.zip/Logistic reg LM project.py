#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import numpy as np
import seaborn as sb
import seaborn as sns
import matplotlib.pyplot as plt
df=pd.read_csv('SBA.csv')
df


# In[3]:


df.shape


# In[4]:


df.duplicated().sum()


# In[5]:


df.isnull().sum()


# In[6]:


print(df.dtypes)


# In[7]:


corr=df.corr() 
corr


# In[18]:


corr=sb.heatmap((df.corr()))


# In[180]:


X=df[['Term']]
Y=df[['Default']]


# In[181]:


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size = 0.2, random_state = 0)


# In[182]:


from sklearn.decomposition import PCA
pca = PCA(n_components = None)
X_train = pca.fit_transform(X_train)
X_test = pca.transform(X_test)
explained_variance = pca.explained_variance_ratio_
explained_variance


# In[183]:


from sklearn.linear_model import LogisticRegression
classifier = LogisticRegression(random_state = 0, max_iter=1000)
classifier.fit(X_train, y_train)


# In[184]:


y_pred = classifier.predict(X_test)


# In[185]:


from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score
cm = confusion_matrix(y_test, y_pred)
tp, fn, fp, tn = confusion_matrix(y_test, y_pred, labels=[1,0]).reshape(-1)

print('outcome values testing data:\n\n')
print('True positive',tp)
print('false negative',fn)
print('false postive',fp)
print('true negative',tn)
print(sep='\n')

plt.figure()
sns.heatmap(cm, annot= True)
plt.xlabel('Prediction')
plt.ylabel('Target')
plt.title('confusion matrix')

## tp = actual & predicted value are same/positive
## fn = actual value is positive & predicted is negative
## fp = actual is negative & predicted is positive
## tn = actual & predicted are same/negative


# In[186]:


accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)


# In[187]:


print("Accuracy:", accuracy)                          ## how better the model is fitted
print("Precision:", precision)                          ## how better the model is predicted
print("Recall:", recall)                               ## how good our model is at correctly predicted value
print("F1 score:", f1)                                      ## average of precision & recall


# In[188]:


get_ipython().system('pip install statsmodel')
import scipy.signal.signaltools

def _centered(arr, newsize):
    # Return the center newsize portion of the array.
    newsize = np.asarray(newsize)
    currsize = np.array(arr.shape)
    startind = (currsize - newsize)  // 2
    endind = startind + newsize
    myslice = [slice(startind[k], endind[k]) for k in range(len(endind))]
    return arr[tuple(myslice)]

scipy.signal.signaltools._centered = _centered
import statsmodels.api as sm
import pandas as pd
x= sm.add_constant(X)
result = sm.OLS(Y,X).fit()
print(result.summary())

